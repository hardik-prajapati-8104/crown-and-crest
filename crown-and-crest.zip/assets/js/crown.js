(function(){
var b=document.querySelector('.burger'),n=document.querySelector('nav');
if(b)b.addEventListener('click',function(){var o=n.classList.toggle('open');b.setAttribute('aria-expanded',o)});
document.querySelectorAll('.filters button').forEach(function(btn){btn.addEventListener('click',function(){
 document.querySelectorAll('.filters button').forEach(function(x){x.classList.remove('on')});btn.classList.add('on');
 var f=btn.dataset.f;document.querySelectorAll('[data-cat]').forEach(function(t){t.style.display=(f==='all'||t.dataset.cat===f)?'':'none'})})});
document.querySelectorAll('form[data-mail]').forEach(function(f){f.addEventListener('submit',function(e){e.preventDefault();
 var d=new FormData(f),body=[];d.forEach(function(v,k){body.push(k+': '+v)});
 location.href='mailto:shwetarroy@gmail.com?subject='+encodeURIComponent('Event enquiry - Crown & Crest')+'&body='+encodeURIComponent(body.join('\n'));
 var m=f.querySelector('.note');if(m)m.textContent='Your email app should open with the enquiry ready to send.'})});
})();
